using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Welcome to the lab portion of CSCI 1301!");
    }
}
